﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace محاضره_الثامنه_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string myword;
       private string [] history = new string[10];//نخزن عشان نفعل تراجع
        int count = 0;// عدد
       //نسخ
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectedText.Length > 0)
            {
                myword = textBox1.SelectedText;
            }
            else
                MessageBox.Show("لايوجد نص محدد");
        }
        //لصق
        private void button3_Click(object sender, EventArgs e)
        {
            if (myword != null)
            {
                history[count++] = textBox2.Text;
                textBox2.Text += myword;
                
            }
            else
                MessageBox.Show("لايوجد نص محدد");
        }
        //قص
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectedText.Length > 0) { 
                myword = textBox1.SelectedText;
                textBox1.SelectedText = null;
            }
            else
                MessageBox.Show("لايوجد نص محدد");
        }

        //نقدر نتراجع حتى 10 كلمات
        private void button4_Click(object sender, EventArgs e)
        {
            if (count > 0)
            {
                count--;
                textBox2.Text = history[count];
               
            }
        }

    
    }
}
