﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace محاضره_الثامنه_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int number = Convert.ToInt32(textBox1.Text);
            if(number<=100)
            //if ((int.TryParse(textBox1.Text.Trim(), out number) && number < 100))
            {
                if (!listBox1.Items.Contains(textBox1.Text))
                {
                    if (listBox1.Items.Count >=20)
                    {
                        listBox1.Items.RemoveAt(0);
                    }
                    listBox1.Items.Add(textBox1.Text);
                    textBox1.Text = null;
                }
                else
                    MessageBox.Show("لايسمح بتكرار عناصر");
            }
            else
                MessageBox.Show(" لايسمح بعناصر اكبر من 100");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                listBox1.Items.Remove(listBox1.SelectedItem);
            }
            else
                MessageBox.Show("حدد على عنصر");

        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int sum = 0;
            //for (int i = 0; i < listBox1.Items.Count; i++)               
            //    sum += Convert.ToInt16(listBox1.Items[i]);   
            foreach (string itme in listBox1.Items)
            {
                sum += int.Parse(itme);
            }
            textBox2.Text = sum.ToString();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            double sum = 0;
            double avg = listBox1.Items.Count;
            for (int i = 0; i < listBox1.Items.Count; i++)
                sum += Convert.ToDouble(listBox1.Items[i]);
            textBox3.Text = (sum/ avg).ToString();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Random r = new Random();
            //for (int i = 0; i < 10; i++)
            //{
            //   int p = (int)(100 * (r.NextDouble()));
            //    listBox1.Items.Add(p.ToString());
            //}
            for (int i = 0; i < 10; i++)
            {
                int p = r.Next(100);
                //listBox1.Items.Contains(p);
                listBox1.Items.Add(p.ToString());
            }

        }
    }
}
