﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace محاضره__الثامنه_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtall_length.Text = txtall_text.Text.Trim().Length.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtall_text.SelectedText.Length > 0)
            {
                txtselect_length.Text = txtall_text.SelectionLength.ToString();
            }
            else
            {
                MessageBox.Show("قم بتحديد النص ");
                txtselect_length.Text = "";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int coount = 0;
            txtnum_word.Text = 0.ToString();
            if (txtall_text.Text.Trim() == "")
                return;
            string strword = txtall_text.Text.Trim().Replace("  ", " ");
            if (txtall_text.Text.Trim().Split(' ').Count() == 1)
            {
                txtnum_word.Text = 1.ToString();
                return;
            }
            txtnum_word.Text = (strword.Split(' ').Count().ToString());
       //     txtnum_word.Text = 0.ToString();
            //string[] strword2 = txtall_text.Text.Trim().Split(' ');
            //int x = 0;
            //for (int i = 0; i < strword2.Length; i++)
            //    if (strword2[i] != " ")
            //        x++;
            //txtnum_word.Text = x.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (txtall_text.SelectionLength > 0)
            {
                txtall_text.SelectedText = "";
            }
            else
            {
                MessageBox.Show("قم بتحديد نص");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtall_text.SelectionLength = 0;
        }
        string myselectedtext = "";
        private void button6_Click(object sender, EventArgs e)
        {
            if (txtall_text.SelectedText.Length > 0)
            {
                myselectedtext = txtall_text.SelectedText;
            }
            else
            {         
                MessageBox.Show("لايوجد نص محدد");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (txtall_text.SelectedText.Length > 0)
            {
                myselectedtext = txtall_text.SelectedText;
              txtall_text.SelectedText = null;
                
            }
            else
            {
                MessageBox.Show("no found");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int x = 0;
            for (int i = 0; i < txtall_text.Text.Length; i++)
            {
                if (txtall_text.Text[i] != ' ')
                {
                    x++;
                }
            }
            MessageBox.Show(x.ToString());
        }

        private void button10_Click(object sender, EventArgs e)
        {
            int x = 0;
            for (int i = 0; i < txtall_text.SelectedText.Length; i++)
            {
                if (txtall_text.Text[i] != ' ')
                {
                    x++;
                }
            }
            MessageBox.Show(x.ToString());
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (txtall_text.SelectionLength > 0)
            {
                if (txtedit_text.Text.Trim() != "")
                {
                    txtall_text.SelectedText = txtedit_text.Text;
                }
                else

                    MessageBox.Show(" ادخل النص الجديد");
            }
            else
                MessageBox.Show(" حدد النص المراد تعديله");

        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (txtsearch.Text.Trim() != "")
            {
                int index = txtall_text.Text.IndexOf(txtsearch.Text, 0);
                if (index > -1)
                {
                    txtall_text.SelectionStart = index;
                    txtall_text.Focus();
                    txtall_text.SelectionLength = txtsearch.Text.Length;
                }
                else
                    MessageBox.Show("not found");
            }
            else
            {
                MessageBox.Show("ادخل النص المراد البحث عنه");
                txtsearch.Focus();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (txtsearch.Text.Trim() != "")
            {
                int index = txtall_text.Text.IndexOf(txtsearch.Text,
                    txtall_text.SelectionStart + txtall_text.SelectionLength);
                if (index > -1)
                {
                    txtall_text.Focus();
                    txtall_text.Select(index, txtsearch.Text.Length);
                }
                else
                    MessageBox.Show("not found");
            }
            else
            {
                MessageBox.Show("ادخل النص المراد البحث عنه");
                txtsearch.Focus();
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (txtsearch.Text.Trim() != "")
            {
                int index = txtall_text.Text.LastIndexOf(txtsearch.Text,
                    txtall_text.SelectionStart - txtall_text.SelectionLength);
                if (index > -1)
                {
                    txtall_text.Focus();
                    txtall_text.Select(index, txtsearch.Text.Length);
                }
                else
                    MessageBox.Show("not found");
            }
            else
            {
                MessageBox.Show("ادخل النص المراد البحث عنه");
                txtsearch.Focus();
            }
        }
        string bufor_idit;
        private void button15_Click(object sender, EventArgs e)
        {
            bufor_idit = txtcopypast.Text;
            txtcopypast.Text += myselectedtext.Trim();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            txtcopypast.Text = bufor_idit;
            //txtcopypast.Undo();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            txtall_text.Clear();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string s = txtall_text.SelectedText;
            char[] ch = s.ToCharArray();
            for (int i = 0; i < ch.Length; i++)
                listBox1.Items.Add(ch[i]);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            string[] s = txtall_text.SelectedText.Split(' ');
            for (int i = 0; i < s.Length; i++)
              listBox2.Items.Add(s[i]);
        }
    }
}
